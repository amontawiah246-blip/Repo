import React, { useEffect, useRef, useState } from "react";
import { Activity, ChevronDown, Code, Ellipsis, House, Menu as MenuIcon } from "lucide-react";
import ChartView, { ChartHandle } from "./ChartView";
import Sheet from "./Sheet";
import BrokerMenu, { BrokerLogo } from "./BrokerMenu";
import MarketPicker from "./MarketPicker";
import MarketIcon from "./MarketIcon";
import ChartMenu from "./ChartMenu";
import TradePanel from "./TradePanel";
import { ModeBox, ModePopup } from "./ModePicker";
import { Home, Api, Menu, StatusData } from "./Pages";
import SignalsPage, { BINARY_BROKERS } from "./SignalsPage";
import DerivTradeTypes from "./DerivTradeTypes";
import { DEFAULT_DERIV_TYPE, DERIV_TYPES, derivTypeOf, tradeBlockReason } from "./derivTypes";
import { AutopilotCard, AutopilotModal, loadCfg, useAutopilot } from "./AutopilotUI";
import { apiFetch } from "./api";
import { shortName, splitName, TIMEFRAMES, BROKERS, Asset, ChartType, CHART_TYPES, Mode, MODES } from "./assets";
import "./styles.css";

const defaultBridge = () => {
  if (typeof window === "undefined") return "localhost:3000";
  const saved = localStorage.getItem("bridge");
  if (saved && !saved.includes(":8765")) {
    return saved;
  }
  return location.host;
};

// Small helpers: remember a choice in this browser, never crash if storage is blocked.
function remembered<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const v = localStorage.getItem(key) as T | null;
    if (v && allowed.includes(v)) return v;
  } catch { /* storage unavailable */ }
  return fallback;
}
const remember = (key: string, value: string) => { try { localStorage.setItem(key, value); } catch { /* ignore */ } };

export default function App() {
  const [tab, setTab] = useState("chart");
  const [bridge, setBridgeState] = useState(defaultBridge);
  const [broker, setBroker] = useState("pocket");
  const [asset, setAsset] = useState("EURUSD_otc");
  const [tf, setTf] = useState(60);
  const [sheet, setSheet] = useState<string | null>(null); // broker | pair | tf | more
  const [assets, setAssets] = useState<Asset[]>([]);
  const [status, setStatus] = useState<StatusData | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [chartType, setChartTypeState] = useState<ChartType>(() => remembered("qx-chart-type", CHART_TYPES.map((c) => c.id), "candles"));
  const [mode, setModeState] = useState<Mode>(() => remembered("qx-mode", MODES.map((m) => m.id), "classic"));
  const [modePop, setModePop] = useState(false);
  const [derivType, setDerivTypeState] = useState<string>(() => remembered("qx-deriv-type", DERIV_TYPES.map((t) => t.id), DEFAULT_DERIV_TYPE));
  const [typePicker, setTypePicker] = useState(false);
  const [toast, setToast] = useState("");
  const chartRef = useRef<ChartHandle>(null);
  const [apModal, setApModal] = useState(false);
  const assetsRef = useRef<Asset[]>([]);
  assetsRef.current = assets;
  const modeRef = useRef<Mode>(mode);
  modeRef.current = mode;

  const setBridge = (v: string) => {
    localStorage.setItem("bridge", v);
    setBridgeState(v);
  };
  const setChartType = (t: ChartType) => { setChartTypeState(t); remember("qx-chart-type", t); };
  const setMode = (m: Mode) => { setModeState(m); remember("qx-mode", m); };
  // Picking a Deriv trade type opens the Pro mode chart with that type.
  const pickDerivType = (id: string) => {
    setDerivTypeState(id); remember("qx-deriv-type", id);
    setMode("pro"); setTypePicker(false); setSheet(null); setModePop(false); setTab("chart");
    setToast(`${derivTypeOf(id).label} · Pro mode`);
  };

  const isHttps = typeof window !== "undefined" && window.location.protocol === "https:";
  const isLocal = bridge.includes("localhost") || bridge.includes("127.0.0.1");
  const httpProto = isHttps && !isLocal ? "https" : "http";
  const wsProto = isHttps && !isLocal ? "wss" : "ws";
  const http = bridge.startsWith("http") ? bridge : `${httpProto}://${bridge}`;
  const wsBase = bridge.startsWith("ws") ? bridge : `${wsProto}://${bridge}`;

  const ap = useAutopilot(http);
  const apBrokerName = BROKERS.find((b) => b.id === ap.broker)?.name ?? "";
  // The bot runs on the server. It only moves your chart while Pro mode is showing and you are on the broker it trades.
  useEffect(() => {
    if (ap.running && ap.st?.focus && mode === "pro" && ap.broker === broker) setAsset(ap.st.focus);
  }, [ap.st?.focus]); // eslint-disable-line react-hooks/exhaustive-deps

  // Status + asset list (payouts change, so refresh every minute).
  useEffect(() => {
    let dead = false;
    const load = async () => {
      try {
        const sRes = await fetch(`${http}/api/status?broker=${broker}`);
        if (sRes.ok) {
          const s = await sRes.json();
          if (!dead) setStatus(s);
        } else if (!dead) {
          setStatus(null);
        }

        const aRes = await fetch(`${http}/api/assets?broker=${broker}`);
        if (aRes.ok) {
          const a = await aRes.json();
          if (!dead && Array.isArray(a)) {
            setAssets(a);
            if (a.length > 0 && !a.some((x) => x.symbol === asset)) {
              setAsset(a[0].symbol);
            }
          }
        }
      } catch {
        if (!dead) setStatus(null);
      }
    };
    load();
    const id = setInterval(load, status?.ready ? 60000 : 3000);
    return () => { dead = true; clearInterval(id); };
  }, [http, broker, status?.ready]);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 2400);
    return () => clearTimeout(id);
  }, [toast]);

  const current = assets.find((a) => a.symbol === asset);
  const currentAsset: Asset = current ?? { symbol: asset };
  const tfLabel = TIMEFRAMES.find((t) => t.sec === tf)?.label;
  const brokerName = BROKERS.find((b) => b.id === broker)?.name || "Pocket Option";
  const modeInfo = MODES.find((m) => m.id === mode);

  const close = () => setSheet(null);

  const account: "DEMO" | "REAL" | "UNKNOWN" = status?.ready && typeof status.demo === "boolean" ? (status.demo ? "DEMO" : "REAL") : "UNKNOWN";
  const switchAccount = async (demo: boolean) => {
    if (ap.running) { setToast("Stop AI Trading before switching accounts"); return; }
    if (!demo && !window.confirm(`Switch ${brokerName} to your REAL account? Trades will use real money.`)) return;
    setToast(`Switching to ${demo ? "demo" : "real"}…`);
    try {
      const r = await apiFetch(`${http}/api/account`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ broker, demo }) });
      const d = await r.json();
      if (d.status !== "ok") { setToast(d.msg || "Could not switch the account"); return; }
      for (let i = 0; i < 8; i++) {   // wait until the broker reports the new account
        await new Promise((res) => setTimeout(res, 1200));
        const sr = await fetch(`${http}/api/status?broker=${broker}`); const st = await sr.json();
        if (st.ready && st.demo === demo) { setStatus(st); setToast(`Now on the ${demo ? "demo" : "real"} account`); return; }
      }
      setToast("Switch sent, but the broker has not confirmed it yet. Check the Home screen.");
    } catch { setToast("Could not reach the server"); }
  };
  const onAi = () => {
    if (ap.running) { void ap.stop(); return; }
    if (!status?.ready) { setToast("Connect the broker first, the bridge is not ready"); return; }
    if (broker === "deriv" && tradeBlockReason(broker, derivType)) { setToast("On Deriv, pick Rise/Fall as the trade type to use AI Trading"); return; }
    setApModal(true);
  };
  const startAuto = async (cfg: ReturnType<typeof loadCfg>) => {
    setApModal(false);
    const err = await ap.start(broker, { ...cfg, scanCount: 60, derivType });
    setToast(err || "AI Trading started. It keeps running on the server.");
  };
  const go = (id: string) => { setTab(id); setSheet(null); setModePop(false); setTypePicker(false); };
  const toggleSheet = (id: string) => { setModePop(false); setSheet((s) => (s === id ? null : id)); };

  const navBtn = (id: string, name: string, icon: React.ReactNode) => (
    <button key={id} className={tab === id ? "on" : ""} onClick={() => go(id)}>
      {icon}
      <span>{name}</span>
    </button>
  );

  return (
    <div className="app">
      {tab === "chart" && (
        <header className="top">
          <button className="chip brk" onClick={() => { setModePop(false); setSheet("broker"); }}>
            <BrokerLogo id={broker} size={26} />
            <span>{brokerName.split(" ")[0].toUpperCase()}</span>
            <ChevronDown size={16} />
          </button>
          <button className={`chip pair ${sheet === "pair" ? "open" : ""}`} onClick={() => toggleSheet("pair")}>
            <MarketIcon asset={currentAsset} small />
            <span className="nm">{shortName(currentAsset)}</span>
            {current?.payout != null && current.payout > 0 && <em>{current.payout}%</em>}
            <ChevronDown size={16} className="chev" />
          </button>
          <button className="chip tfc" onClick={() => { setModePop(false); setSheet("tf"); }}>
            {tfLabel}
            <ChevronDown size={16} />
          </button>
          <button className={`icon dots ${sheet === "more" ? "on" : ""}`} onClick={() => toggleSheet("more")} aria-label="Chart options">
            <Ellipsis size={20} />
          </button>
        </header>
      )}

      <main>
        {tab === "home" && <Home status={status} brokerName={brokerName} onOpenChart={() => go("chart")} onSwitchAccount={switchAccount} />}
        {tab === "signals" && (
          <SignalsPage
            wsBase={wsBase}
            apiBase={http}
            broker={broker}
            setBroker={setBroker}
            asset={asset}
            setAsset={setAsset}
            assets={assets}
            onOpenChart={() => go("chart")}
            onToast={setToast}
            derivType={derivType}
            onPickDerivType={pickDerivType}
          />
        )}
        {tab === "chart" && (
          <ChartView ref={chartRef} wsBase={wsBase} broker={broker} asset={asset} tf={tf} reloadKey={reloadKey} chartType={chartType} />
        )}
        {tab === "chart" && mode === "pro" && ap.st && (
          <AutopilotCard st={ap.st} cfg={ap.cfg ?? loadCfg()} brokerLabel={apBrokerName} running={ap.running} onStop={() => void ap.stop()} onDismiss={() => void ap.dismiss()} />
        )}
        {tab === "chart" && (
          <TradePanel
            http={http}
            broker={broker}
            asset={asset}
            assetLabel={splitName(currentAsset).label}
            payout={current?.payout ?? undefined}
            closed={current?.active === false}
            mode={mode}
            autoOn={ap.running}
            blockReason={tradeBlockReason(broker, derivType)}
            onAi={onAi}
            onToast={setToast}
          />
        )}
        {tab === "api" && <Api bridge={bridge} setBridge={setBridge} broker={broker} status={status} />}
        {tab === "menu" && <Menu />}

        {tab === "chart" && mode === "ai" && <div className={`modebadge ${mode}`}>{modeInfo?.label} · coming soon</div>}
        {tab === "chart" && mode === "pro" && broker === "deriv" && (
          <button className="typechip" onClick={() => { setSheet(null); setModePop(false); setTypePicker(true); }}>
            {derivTypeOf(derivType).label}<ChevronDown size={14} />
          </button>
        )}
        {tab === "chart" && typePicker && (
          <DerivTradeTypes variant="overlay" current={derivType} onBack={() => setTypePicker(false)} onPick={pickDerivType} />
        )}

        {tab === "chart" && sheet === "pair" && (
          <MarketPicker broker={broker} assets={assets} selected={asset} onPick={(s) => { setAsset(s); close(); }} onClose={close} />
        )}
        {tab === "chart" && sheet === "more" && (
          <ChartMenu
            chart={chartRef.current}
            chartType={chartType}
            onType={setChartType}
            onReset={() => setReloadKey((k) => k + 1)}
            onToast={setToast}
            onClose={close}
          />
        )}
      </main>

      {toast && <div className="toast" role="status">{toast}</div>}

      <div className="navwrap">
        {modePop && (
          <ModePopup
            mode={mode}
            onClose={() => setModePop(false)}
            onPick={(m) => { setMode(m); setModePop(false); setTab("chart"); setSheet(null); }}
          />
        )}
        {tab !== "chart" && mode === "pro" && ap.st && (
          <div className={`apbar ${ap.running ? "on" : ""}`} onClick={() => go("chart")}>
            <i /><span>{ap.running ? "AI Trading running" : "AI Trading stopped"} · {ap.st.stats.trades} trades · P&amp;L {ap.st.stats.pnl > 0 ? "+" : ""}{ap.st.stats.pnl}</span>
            {ap.running && <button onClick={(e) => { e.stopPropagation(); void ap.stop(); }}>Stop</button>}
          </div>
        )}
        <nav className="bottom">
          {navBtn("home", "Home", <House size={20} />)}
          {navBtn("signals", "Signals", <Activity size={20} />)}
          <ModeBox mode={mode} open={modePop} onClick={() => { setSheet(null); setModePop((o) => !o); }} />
          {navBtn("api", "API", <Code size={20} />)}
          {navBtn("menu", "Menu", <MenuIcon size={20} />)}
        </nav>
      </div>

      {apModal && (
        <AutopilotModal brokerName={brokerName} broker={broker} account={account} onSwitchAccount={switchAccount} defaultStake={Number(localStorage.getItem("qx-amount")) || 10} onStart={startAuto} onCancel={() => setApModal(false)} />
      )}

      {sheet === "broker" && (
        <BrokerMenu current={broker} onPick={(id) => { setBroker(id); close(); }} onClose={close} />
      )}

      {sheet === "tf" && (
        <Sheet title="Timeframe" onClose={close}>
          {TIMEFRAMES.map((t) => (
            <button key={t.sec} className={`item ${t.sec === tf ? "sel" : ""}`} onClick={() => { setTf(t.sec); close(); }}>
              <span>{t.label}</span>
            </button>
          ))}
        </Sheet>
      )}
    </div>
  );
}
